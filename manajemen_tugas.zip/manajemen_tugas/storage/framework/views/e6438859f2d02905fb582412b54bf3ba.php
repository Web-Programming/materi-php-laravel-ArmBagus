

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">
    <i class="fas fa-tasks mr-2"></i>
    <?php echo e($title); ?>

</h1>

<div class="card">
    <div class="card-header d-flex flex-wrap justify-content-between align-items-center">
        <!-- Tombol Tambah Data di kiri -->
        <div class="mb-1">
            <a href="<?php echo e(route('tugasCreate')); ?>" class="btn btn-sm btn-primary">
                <i class="fas fa-plus mr-2"></i>
                Tambah Data
            </a>
        </div>

        <!-- Tombol Excel & PDF di kanan -->
        <div class="d-flex gap-2">
            <a href="#" class="btn btn-sm btn-success me-2">
                <i class="fas fa-file-excel mr-2"></i>
                Excel
            </a>
            <a href="#" class="btn btn-sm btn-danger">
                <i class="fas fa-file-pdf mr-2"></i>
                PDF
            </a>
        </div>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead class="bg-primary text-white">
                    <tr class="text-center">
                        <th>No</th>
                        <th>Nama</th>
                        <th>Tugas</th>
                        <th>Tanggal Mulai</th>
                        <th>Tanggal Selesai</th>
                        <th>
                            <i class="fas fa-cog"></i>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->user->nama); ?></td>
                        <td><?php echo e($item->tugas); ?></td>
                        <td class="text-center">
                                <span class="badge badge-info">
                                    <?php echo e($item->tanggal_mulai); ?>

                                </span>
                        </td>
                        <td class="text-center">
                            <span class="badge badge-info">
                                    <?php echo e($item->tanggal_selesai); ?>

                            </span></td>

                        </td>
                        <td class="text-center">
                             <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#modalTugasShow<?php echo e($item->id); ?>">
                             <i class="fas fa-eye"></i>
                            </button>
                            
                            <a href="<?php echo e(route('tugasEdit', $item->id )); ?>" class="btn btn-sm btn-warning">
                                <i class="fas fa-edit"></i>
                            </a>

                            <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modalTugasDestroy<?php echo e($item->id); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                            <?php echo $__env->make('admin/tugas/modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bagus\OneDrive\文件\GitHub\materi-php-laravel-ArmBagus\manajemen_tugas\resources\views/admin/Tugas/index.blade.php ENDPATH**/ ?>