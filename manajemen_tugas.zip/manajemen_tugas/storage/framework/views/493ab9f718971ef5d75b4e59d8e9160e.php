

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">
    <i class="fas fa-user mr-2"></i>
    <?php echo e($title); ?>

</h1>

<div class="card">
    <div class="card-header d-flex flex-wrap justify-content-between align-items-center">
        <!-- Tombol Tambah Data di kiri -->
        <div class="mb-1">
            <a href="<?php echo e(route('userCreate')); ?>" class="btn btn-sm btn-primary">
                <i class="fas fa-plus mr-2"></i>
                Tambah Data
            </a>
        </div>

        <!-- Tombol Excel & PDF di kanan -->
        <div class="d-flex gap-2">
            <a href="#" class="btn btn-sm btn-success me-2">
                <i class="fas fa-file-excel mr-2"></i>
                Excel
            </a>
            <a href="#" class="btn btn-sm btn-danger">
                <i class="fas fa-file-pdf mr-2"></i>
                PDF
            </a>
        </div>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead class="bg-primary text-white">
                    <tr class="text-center">
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Jabatan</th>
                        <th>Status</th>
                        <th>
                            <i class="fas fa-cog"></i>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->nama); ?></td>
                        <td class="text-center">
                            <span class="badge badge-primary">
                                <?php echo e($item->email); ?>

                            </span>
                        </td>
                        <td class="text-center">
                            <?php if($item->jabatan =='Admin'): ?>
                            <span class="badge badge-dark">
                                <?php echo e($item->jabatan); ?>

                            </span>
                            <?php else: ?>
                            <span class="badge badge-info">
                                <?php echo e($item->jabatan); ?>

                            </span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if($item->is_tugas == false): ?>
                            <span class="badge badge-danger">
                                Belum Ditugaskan
                            </span>
                            <?php else: ?>
                            <span class="badge badge-success">
                                Sudah Ditugaskan
                            </span>
                            <?php endif; ?>

                        </td>
                        <td class="text-center">
                            <a href="<?php echo e(route('userEdit', $item->id )); ?>" class="btn btn-sm btn-warning">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#exampleModal<?php echo e($item->id); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                            <?php echo $__env->make('admin/user/modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bagus\OneDrive\文件\GitHub\materi-php-laravel-ArmBagus\manajemen_tugas\resources\views/admin/user/index.blade.php ENDPATH**/ ?>